package com.restur.msgrtest.consts;

public enum ModelTypes {
    CHAT,
    USER,
    OWNER,
    MESSAGE
}

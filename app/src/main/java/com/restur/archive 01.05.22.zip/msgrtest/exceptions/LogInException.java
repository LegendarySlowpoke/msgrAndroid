package com.restur.msgrtest.exceptions;

public class LogInException extends Throwable {
    public LogInException(String message) {
        super(message);
    }
}

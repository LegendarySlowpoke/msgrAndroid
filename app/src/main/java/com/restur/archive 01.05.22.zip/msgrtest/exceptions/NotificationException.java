package com.restur.msgrtest.exceptions;

public class NotificationException extends Throwable {
    public NotificationException(String message) {
        super(message);
    }
}

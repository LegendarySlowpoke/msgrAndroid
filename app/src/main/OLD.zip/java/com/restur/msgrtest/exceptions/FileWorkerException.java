package com.restur.msgrtest.exceptions;

public class FileWorkerException extends Throwable {
    public FileWorkerException(String message) {
        super(message);
    }
}

package com.restur.msgrtest.exceptions;

public class ConnectionException extends Throwable {
    public ConnectionException(String message) {
        super(message);
    }
}

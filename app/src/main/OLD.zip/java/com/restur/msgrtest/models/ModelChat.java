package com.restur.msgrtest.models;

import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class ModelChat implements Serializable {
    //Main data
    private final Long id;
    private String chatName;
    private Long creatorId;
    private List<Long> usersList;

    private LinkedList<ModelMessage> messages = new LinkedList<>();
    private boolean democracy;

    //additional
    private Map<Long, ModelMessage> mapMessages;

    public ModelChat(Long id, String chatName, Long creatorId, List<Long> usersList,
                     List<ModelMessage> messages, boolean democracy) {
        this.id = id;
        this.chatName = chatName;
        this.creatorId = creatorId;
        this.usersList = usersList;

        //Sorting messages & adding them to LinkedList
        Collections.sort(messages, ModelMessage.Comparators.ID);
        this.messages.addAll(messages);

        this.democracy = democracy;
    }

    public String getLastMessageString() {
        return messages.getLast().getMessage();
    }

    //Getters
    public Long getId() {
        return id;
    }

    public String getChatName() {
        return chatName;
    }

    public Long getCreatorId() {
        return creatorId;
    }

    public List<Long> getUsersList() {
        return usersList;
    }

    public LinkedList<ModelMessage> getMessages() {
        return messages;
    }

    public boolean isDemocracy() {
        return democracy;
    }

    public Map<Long, ModelMessage> getMapMessages() {
        return mapMessages;
    }
}

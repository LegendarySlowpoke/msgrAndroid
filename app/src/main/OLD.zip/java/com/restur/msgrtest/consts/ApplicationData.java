package com.restur.msgrtest.consts;

import android.content.Context;
import android.os.StrictMode;

import com.restur.msgrtest.connection.Connector;
import com.restur.msgrtest.exceptions.FileWorkerException;
import com.restur.msgrtest.models.ModelChat;
import com.restur.msgrtest.models.ModelMessage;
import com.restur.msgrtest.models.ModelOwner;
import com.restur.msgrtest.models.ModelUser;
import com.restur.msgrtest.serviceWorkers.DeviceInfoWorker;
import com.restur.msgrtest.serviceWorkers.FileWorkers;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;

public class ApplicationData {
    //File names
    private final static String ownerModelFileName = "q1.msgr";
    private final static String chatModelListFileName = "q2.msgr";
    private final static String userModelFileName = "q3.msgr";
    private final static String messageModelModelFileName = "q4.msgr";

    //Entities
    private static Context appContext;
    private static Connector connector;

    private static ModelOwner owner;
    private static List<ModelChat> chatList = new ArrayList<>();
    private static List<ModelUser> userList = new ArrayList<>();
    private static List<ModelMessage> messageList = new ArrayList<>();

    //READING ownerModel, chatList, userList and messageList from file
    static {
        try {
            try {
                owner = (ModelOwner) FileWorkers.readFileObject(ApplicationData.ownerModelFileName);
            } catch (FileWorkerException e) {
                e.printStackTrace();
            }

            try {
                for (Object jsonObject :
                        FileWorkers.readFileArray(ApplicationData.chatModelListFileName)) {
                    chatList.add((ModelChat) jsonObject);
                }
            } catch (FileWorkerException e) {
                e.printStackTrace();
            }

            try {
                for (Object jsonObject :
                        FileWorkers.readFileArray(ApplicationData.userModelFileName)) {
                    userList.add((ModelUser) jsonObject);
                }
            } catch (FileWorkerException e) {
                e.printStackTrace();
            }

            try {
                for (Object jsonObject :
                        FileWorkers.readFileArray(ApplicationData.messageModelModelFileName)) {
                    messageList.add((ModelMessage) jsonObject);
                }
            } catch (FileWorkerException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        setConnector();
    }

    //SAVING data to file
    public static void saveToFile(ModelTypes modelType) {
        switch (modelType) {
            case OWNER:
                FileWorkers.writeFile(owner, ApplicationData.ownerModelFileName);
                break;
            case USER:
                FileWorkers.writeFile(userList, ApplicationData.userModelFileName);
                break;
            case CHAT:
                FileWorkers.writeFile(chatList, ApplicationData.chatModelListFileName);
                break;
            case MESSAGE:
                FileWorkers.writeFile(messageList, ApplicationData.messageModelModelFileName);
                break;
        }
    }

    //Establishing connection
    public static void setConnector() {
        //Allowing connection
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    connector = new Connector(PathsToServer.getServerPathIp(),
                            PathsToServer.getServerPathPort());
                } catch (ConnectException e) {
                    e.printStackTrace();
                    System.out.println(e);
                }
            }
        });
        thread.run();

    }


    //Setters & Getters

    public static Connector getConnector() { return connector; }

    public static void setAppContext(Context appContext) {
        ApplicationData.appContext = appContext;
    }
    public static Context getAppContext() {
        return appContext;
    }

    public static void setOwner(ModelOwner modelOwner) {
        owner = modelOwner;
    }
    public static ModelOwner getOwner() {
        return owner;
    }

    public static String getPhoneId(Context context) {
        return DeviceInfoWorker.getImeiHashThisDevice(context);
    }

    public static String getOwnerModelFileName() {
        return ownerModelFileName;
    }

    public static List<ModelChat> getChatList() {
        return chatList;
    }

    public static List<ModelUser> getUserList() {
        return userList;
    }

    public static List<ModelMessage> getMessageList() {
        return messageList;
    }
}
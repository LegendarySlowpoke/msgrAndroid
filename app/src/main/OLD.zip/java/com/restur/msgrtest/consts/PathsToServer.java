package com.restur.msgrtest.consts;

public class PathsToServer {
    //Main paths
    public static String getServerPathHTTP() {
        return "http://192.168.1.203:8080";
    }
    public static String getServerPathIp() {return "http://192.168.1.203";}
    public static int getServerPathPort() {return 8080;}
    public static String getServerPathWP() {return "wp://192.168.1.203";}


    //User paths
    public static String getUserPath() {
        return "/user";
    }

    public static String getRegistrationPath() { return "/registration"; }

    public static String getLoginPath() { return "/login"; }

    public static String getCheckLoginPath() {return "/checkLogin";}

    public static String getChatList() {return "/getChatList";}



    //Chat paths
    public static String getChatPath() {
        return "/chat";
    }


}
package com.restur.msgrtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.restur.msgrtest.adapters.AdapterChat;
import com.restur.msgrtest.adapters.AdapterChatTest;
import com.restur.msgrtest.consts.ApplicationData;
import com.restur.msgrtest.models.ChatTester;
import com.restur.msgrtest.models.ModelChat;

import java.util.List;

public class ChatListActivity extends AppCompatActivity {

    RecyclerView chatRecycler;
    AdapterChatTest chatAdapterTest;
    AdapterChat chatAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);
        setChatRecycler(ApplicationData.getChatList());

        /*
        List<ChatTester> chatList = new ArrayList<>();
        chatList.add(new ChatTester("Pedro", 134345, "The climate crisis has fueled a surge for Green or climate-centered parties in places like Germany and Norway. In Canada, the Greens are struggling, but the progressive New Democratic Party (NDP), led by Jagmeet Singh, has capitalized on the interest."));
        chatList.add(new ChatTester("Jack", 1234, "What was extraordinary about this summer was that records were being shattered not just by the usual fraction of a degree but by huge margins. Lytton, the Canadian village that was burned down by wildfires, also experienced the country's hottest temperature on record in late June, hitting 49.6 degrees Celsius (121 degrees Fahrenheit). That's more than 4 degrees higher than the previous record."));
        chatList.add(new ChatTester("Alex", 6756465, "Another critical thing that's been happening is that media coverage has both increased in quantity and in quality,\" Leiserowitz said. \"And the third critical piece is, of course, these extreme events -- all-time, record-setting and just eye-popping kinds of disasters happening around the world, which is increasingly being attributed to being made more severe by climate change"));
        chatList.add(new ChatTester("Andrew", 235435, "Clearly, climate change was something that a lot of Canadians were experiencing or have experienced in ways that perhaps they hadn't before, Shane Gunster, an associate professor in the School of Communication at Simon Fraser University in British Columbia, told CNN."));
        chatList.add(new ChatTester("Maria", 3453, "In the run-up to Canada's parliamentary vote, the climate crisis has featured heavily in campaign activities, media coverage and debates. It was the same story in Norway, which voted last Monday, and in Germany, which will hold its elections on September 26."));
        chatList.add(new ChatTester("Brad",13243, "Canadians, who go to the polls on Monday, are among several nations casting votes on the heels of record-smashing, often deadly extreme weather this summer, boosted by climate change. Hundreds of people died in the US and Canada and dozens others in the Mediterranean from heat and fires, while flash floods killed more than 220 people in Germany and Belgium, and more than 300 in China."));
        chatList.add(new ChatTester("Mathew", 234254, "(CNN)It was just last week that Canada's British Columbia finally ended its state of emergency, more than two months after wildfires tore through parts of the province and reduced an entire village and its surroundings to ash.\n" +
                "\n" +
                "It wasn't a random, unfortunate disaster. Scientists said the heatwave that supercharged the fires was \"virtually impossible\" without the greenhouse gases trapped in the atmosphere -- now at the highest concentration in more than 800,000 years -- put there by humans driving, flying, working and eating, and all the other things we humans do that rely on fossil fuels." ));
        chatList.add(new ChatTester("Arthur", 2453, "bsddgff dg dgfd dg dgff "));
        chatList.add(new ChatTester("Alex", 96984, "dfvdfbd fdg d"));
        chatList.add(new ChatTester("Martin", 565345, "fobjnsdfmadpfogmsoigmf,sdgosdmfg"));
        chatList.add(new ChatTester("Онотоле", 4253, "bye!"))
        setChatRecyclerTest(chatList);

         */
    }


    private void setChatRecycler(List<ModelChat> chats) {
        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        chatRecycler = findViewById(R.id.chat_recycler);
        chatRecycler.setLayoutManager(layoutManager);

        chatAdapter = new AdapterChat(this, chats);
        chatRecycler.setAdapter(chatAdapterTest);
    }



    //to be deleted
    private void setChatRecyclerTest(List<ChatTester> chats) {
        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        chatRecycler = findViewById(R.id.chat_recycler);
        chatRecycler.setLayoutManager(layoutManager);

        chatAdapterTest = new AdapterChatTest(this, chats);
        chatRecycler.setAdapter(chatAdapterTest);
    }
}